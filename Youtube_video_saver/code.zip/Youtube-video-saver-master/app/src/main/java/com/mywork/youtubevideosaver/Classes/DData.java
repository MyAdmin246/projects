package com.mywork.youtubevideosaver.Classes;

public class DData {
    private String thumbnailUrl;
    private int defaultFormatId;
    private int duration;
    private String title;

    public String getThumbnailUrl() {
        return thumbnailUrl;
    }

    public void setThumbnailUrl(String thumbnailUrl) {
        this.thumbnailUrl = thumbnailUrl;
    }

    public int getDefaultFormatId() {
        return defaultFormatId;
    }

    public void setDefaultFormatId(int defaultFormatId) {
        this.defaultFormatId = defaultFormatId;
    }

    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}
