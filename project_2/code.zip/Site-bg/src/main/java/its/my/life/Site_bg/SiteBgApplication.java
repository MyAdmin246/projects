package its.my.life.Site_bg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SiteBgApplication {

	public static void main(String[] args) {
		SpringApplication.run(SiteBgApplication.class, args);
	}

}
