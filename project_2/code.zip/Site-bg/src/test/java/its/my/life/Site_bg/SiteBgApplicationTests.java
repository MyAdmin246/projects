package its.my.life.Site_bg;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SiteBgApplicationTests {

	@Test
	void contextLoads() {
	}

}
